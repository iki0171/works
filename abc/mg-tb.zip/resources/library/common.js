$(function() {

    ui.accodianInit();

    // 아코디언 개별 열기 
    // parameter 열릴 아코디언 $('.cnt_title') 인덱스  
    // ex) ui.accodianAll(2,3); ui.accodianAll(2);
    // ui.accodianAll(); 

    // 아코디언 모두열기
    // ui.accodianAllOpen(); 
    
    // 아코디언 모두닫기
    // ui.accodianCloseAll(); 

    ui.productSelect();

    // 탭메뉴
    $(".tab_cnt").eq($("ul.tabs > li.active").index()).show();
    
    $("ul.tabs > li").click(function() {
        $("ul.tabs > li").removeClass("active");
        $(this).addClass("active");
        $(".tab_cnt").hide();
        var activeTab = $(this).attr("rel");
        $("#" + activeTab).show();
    });

    // 카드선택 > 보유카드 선택시 컬러변경
    $("select").change(function() {
        $(this).removeClass("color6");
        
        if($(this).find("option:selected").attr("data-hold") == "Y"){
            $(this).addClass("color6");
        }
    });

    ui.drop2DepthMenu(); // dropdown sub menu
});

const ui = {};

ui.accodianInit = () => {
    const $wrap = $('.cnt_group');
    const t1 = `.cnt_title:not('.etc')`;
    const t2 = '.ui_accordion_clicker';
    // const t3 = '.ui_accordion_clicker_reverse';

    $wrap.on('click', t1, ui.accodianBtnHandler); // 타이틀 클릭
    $wrap.on('change', t2, ui.accodianChkHandler); // 체크박스 클릭
    // $wrap.on('change', t3, ui.accodianChkHandlerReverse); // 체크박스 클릭

    $(window).ready( () => $(t2).each((i,item) => ui.accodianChkHandler($(item)))) // 체크박스형 아코디언 window 로딩후 체크
    // $(window).ready( () => $(t3).each((i,item) => ui.accodianChkHandlerReverse($(item)))) // 체크박스형 아코디언 window 로딩후 체크
}

ui.accodianBtnHandler = e => { // 타이틀 클릭시 off 클레스 검사
    const $t = $(e.target);
    const $p = $t.parents('li');
    
    if ( $p.hasClass('off') ) {
        ui.accodianOpen($t);
        return;
    } 
    ui.accodianClose($t);
}

ui.accodianChkHandler = e => { // 체크박스형 아코디언 상태값 체크
    const $t = e.target ? $(e.target): $(e);

    if ( !$t.is(':checked') ) {
        ui.accodianClose($t.parents('.cnt_title'));
        return;
    } 
    ui.accodianOpen($t.parents('.cnt_title'));
}

ui.accodianChkHandlerReverse = e => { // 체크박스형 아코디언 상태값 체크
    const $t = e.target ? $(e.target): $(e);

    if ( !$t.is(':checked') ) {
        ui.accodianOpen($t.parents('.cnt_title'));
        return;
    } 
    ui.accodianClose($t.parents('.cnt_title'));
}

ui.accodianOpen = $t => { // 아코디언 컨텐츠 열기
    const $p = $t.parents('li');
    
    $p.find('.cnt_body').slideDown('fast');
    $p.removeClass('off');
    // $t.children('span').text('닫기');
}

ui.accodianClose = $t => { // 아코디언 컨텐츠 닫기
    const $p = $t.parents('li');

    $p.find('.cnt_body').slideUp('fast',() => {
        $p.addClass('off');
        // $t.children('span').text('열기');
    });
}

ui.accodianOpenAll = () => { // 아코디언 전체 열기
    const $t = $('.cnt_group .cnt_title').not('.etc');

    $t.each( (i,item) => {
        ui.accodianOpen($(item));
    });
}

ui.accodianCloseAll = (...idx) => { // 아코디언 전체 닫기
    return ui.accodianAll(...idx);
}

ui.accodianAll = (...idx) => { // 아코디언 부분 열기 (일괄)
    const $t = $('.cnt_group .cnt_title').not('.etc');
    const idxArr = [...idx];
    
    $t.each( (i,t) => {
        if ( idxArr.some(idx => idx === i) ) {
            ui.accodianOpen($(t));
        }else{
            ui.accodianClose($(t));
        }
        return;
    });
}

ui.zIndex = 2000;
ui.popupOn = p => { 
    const t = p ? p : '.pop_wrap';
    $(t).addClass('on').css({zIndex:ui.zIndex++});
    ui.bodyScroll('on','layerpop');
}

ui.popupOff = p => { 
    const t = p ? p : '.pop_wrap';
    $(t).removeClass('on');
    ui.bodyScroll('off','layerpop');
}

ui.loadingOn = p => { 
    $('.loading_bar').addClass('on');
    ui.bodyScroll('on','loading');
}

ui.loadingOff = p => { 
    $('.loading_bar').removeClass('on');
    ui.bodyScroll('off','loading');
}

ui.bodyScroll = (state,datasetName) => {
    switch (state) {
        case 'on': return $('body').attr(`data-${datasetName}`,true);
        case 'off': return $('body').attr(`data-${datasetName}`,false);
    }
}


// 예금>상품선택시 콤보박스 활성화
ui.productSelect = () => {
    const $prodBtn = $('.prod_btn');
    const $prodSel = $('.prod_sel');
    const $manual = $('.manual');

    $prodSel.prop("disabled", true);
    $prodBtn.click(function(e) {
        $prodBtn.removeClass("on");
        $(this).addClass("on");
        $prodSel.prop('disabled', false);

        e.preventDefault();
    })
    
    $prodSel.change(function() {
        if($prodSel.eq(0).find("option:selected").index() !== 0 
        && $prodSel.eq(1).find("option:selected").index() !== 0) {
            $manual.removeClass('off');
        } else {
            $manual.addClass('off');
        }
    });
}

ui.testFloatBtnInit = () => {
    $('body').append(`
    <div class="floating_area visible">
        <div class="float_btns">
            <button type="button" data-type="zoom">
                <span class="front">화면확대</span>
                <span class="back">화면축소</span>
            </button>
            <button type="button" data-type="flip">
                <span class="front">화면전환</span>
                <span class="back">화면전환</span>
            </button>
            <button type="button" data-type="theme">
                <span class="front">다크모드</span>
                <span class="back">라이트모드</span>
            </button>
        </div>
        <button type="button" data-type="float">
            <span class="front"></span>
            <span class="back"></span>
        </button>
    </div>
    `)
    ui.setFloatBtnHandler();
}

ui.resizeTimeout;
ui.displayFloatArea = $t => {

    if ( ui.resizeTimeout != null ) clearTimeout(ui.resizeTimeout);

    if( !ui.scrollDirection ) {
        ui.resizeTimeout = setTimeout( ()=> {
            $t.addClass('visible')
        } , 500);
        return;
    }

    ui.resizeTimeout = setTimeout( ()=> {
        $t.removeClass('visible')
    } , 500);
    
}


ui.setFloatBtnHandler = () => {
    const $floatArea = $('.floating_area');

    $(window).on('scroll', e => {
        ui.windowScroll(e);
        // ui.displayFloatArea($floatArea);
    });
    $('.floating_area').on('click', 'button', ui.floatBtnController);
}

// document scroll direction check
ui.scrollDirection = true;
ui.windowScroll = e => {
    const type = scrollY > (ui.scrollPastY | 0);
    ui.scrollPastY = scrollY;
    ui.scrollDirection = type;
}

ui.floatBtnController = e => {
    const target = e.target.parentNode;
    const type = target.dataset.type;

    if ( target.tagName !== 'BUTTON') return;
    
    switch (type) {
        case null: 
            break;

        case 'theme': 
            ui.theme();
            break;
        
        case 'flip': 
//            ui.flip();
            nativeUtil.callNative('reverseOrientation', '');
            break;

        case 'zoom': 
            ui.zoom();
            break;

        case 'float':
            ui.floatBtnDisplay(target);
            break;
    }

    $(target).toggleClass('on');
}

ui.theme = () => {
    const dataset = document.querySelector('html').dataset.dark;

    ui.datasetUpdate('dark', dataset === 'active'?'inactive': 'active');
    commonUtil.setFloatingInfo(dataset === 'active'?'N': 'Y', '');
}

ui.zoom = () => {
    const dataset = document.querySelector('html').dataset.zoom;

    ui.datasetUpdate('zoom', dataset === 'active'?'inactive': 'active');
    commonUtil.setFloatingInfo('', dataset === 'active'?'N': 'Y');
}

ui.flip = () => {
    console.log('flip');
    
    const dataset = document.querySelector('html').dataset.flip;
    ui.datasetUpdate('flip', dataset === 'active'?'inactive': 'active');
    // something(); // 화면 회전 함수 필요
}

ui.floatBtnDisplay = btn => {
    const $floatArea = $('.floating_area');
    const $floatBtns = $('.float_btns');
    const $floatOnBtn = $(btn);
    const animateEasing = 'easeOutQuart';

    if( $floatOnBtn.hasClass('on') ) {
        $floatBtns.stop().animate({
            'margin-bottom':'-=4',
            'opacity': 0
        }, 300, animateEasing,
        ()=>$floatArea.removeClass('on'));
        return;
    }

    $floatArea.addClass('on');
    $floatBtns.stop().animate({
        'margin-bottom':0,
        'opacity':1
    }, 300, animateEasing);
}

ui.drop2DepthMenu = () => {

    const animateTimer = 330;
    const animateEasing = 'easeOutQuart';
    const $wrapMenu = $('.wrap_menu_sub');
    const $menuSub = $('.menu_sub');

    $('.pageTitle').on('click',function(){

        $wrapMenu.addClass('on');
        $menuSub
        .css({
            top: -10,
            opacity: .7
        })
        .animate({
            top: 0,
            opacity: 1
        },animateTimer, animateEasing);

        $wrapMenu.one('click',() => {
            $wrapMenu.removeClass('on');
        });
    });
}

ui.datasetUpdate = (names, value) => {
    document.querySelector('html').dataset[names] = value;
};

// ui.skinLists = ['default', 'skin01', 'skin02', 'skin03'];