(function (global, $) {
    'use strict'

    $('a').click(function () {
        if ($(this).attr('href') == '#none') {
            return false
        };
    });

    $('.html').not('.not').each(function () {
        var $this = $(this);
        var code = $this.html();
        var $btn = $('<a class="g-btn">view html</a>');
        $this.after('<code class="code-view xml"></code>');
        var $view = $this.next($('.code-view'));
        $view.text(code).wrap('<pre />');
        $this.after($btn);

        if ( $this.hasClass('only_source') ) {
            $this.hide();
        }
    });

    $('code.javascript').each(function () {
        $('<a class="g-btn">script</a>').insertBefore($(this).parent());
    });

    $('.g-btn').click(function () {
        $(this).toggleClass('open');
        $(this).next('pre').toggle();
    })

    $('code.xml, code.javascript').each(function () {
        var html = $(this).html(),
            lineMatch = html.match(/\n/g);

        if (lineMatch) {
            var spaceMath = html.match(/^(\s|\t)+/);
            if (spaceMath) {
                html = html.replace(new RegExp(spaceMath[0], 'mg'), '\n');
            }
        } else {
            html = html.replace(/^\s+/, '');
        };

        $(this).html(html);

    })

	$('pre code').each(function (i, block) {
		hljs.highlightBlock(block);
	});

	$(".lnb li a").click(function() {
        var idx = $(".lnb li a").index(this);
		$(".lnb li").removeClass("on");
        $(".lnb li").eq(idx).addClass("on");
	});

}(window, window.jQuery))
