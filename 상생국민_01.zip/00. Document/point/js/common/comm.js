var _gf = {
	initPaging : function(pageNo, pagePerCnt, totalCnt, callbackFn, $scope){
		
		var pageIndex   = pageNo;
		var pageSize    = pagePerCnt;
		var maxPageView = "10";
		var paginationHtml  = "";
		var lastPageIndex   = Math.ceil(totalCnt/pageSize);
		var startPage       = 1 + Number(maxPageView) * Math.floor((pageIndex -1) / Number(maxPageView));
		var endPage         = startPage + (Number(maxPageView) - 1);
		if(endPage > lastPageIndex) endPage = lastPageIndex;
		if(endPage == 0) endPage = 1;
		var pageBlockCnt    = Math.ceil(lastPageIndex/maxPageView);
		if(pageBlockCnt == 0) pageBlockCnt = 1;
		var currentBlock    = Math.ceil(pageIndex/maxPageView);

		if (jexjs.isNull($scope)) $scope = $(document);
	
		$scope.find(".paging").empty();
	
		var prevNo = currentBlock*Number(maxPageView)-Number(maxPageView)+1-Number(maxPageView);
		if(prevNo < 1) prevNo = 1;
		
		paginationHtml += '<a class="btn_pag_cntr first '+(pageNo==1?'':'on pagingBtn')+'" data-page-no="1"><span class="blind">first</span></a>';
		paginationHtml += '<a class="btn_pag_cntr prev '+(pageNo==1?'':'on pagingBtn')+'" data-page-no="'+prevNo+'"><span class="blind">first</span></a>';
	
		paginationHtml += '<span class="pag_num">';
		for(i=startPage; i<=endPage; i++) {
			if(i == Number(pageIndex)) {
				paginationHtml += '<a data-page-no="'+i+'" class="on">'+i+'</a>';
			} else {
				paginationHtml += '<a data-page-no="'+i+'" class="pagingBtn">'+i+'</a>';
			}
		}
		paginationHtml += '</span>';
	
		paginationHtml += '<a class="btn_pag_cntr next '+(pageBlockCnt==currentBlock?'':'on pagingBtn')+'" data-page-no="'+(currentBlock*Number(maxPageView)-Number(maxPageView)+1+Number(maxPageView))+'"><span class="blind">last</span></a>';
		paginationHtml += '<a class="btn_pag_cntr last '+(pageNo==lastPageIndex?'':'on pagingBtn')+'" data-page-no="'+lastPageIndex+'"><span class="blind">last</span></a>';
	
		$scope.find(".paging").empty().append(paginationHtml);
	
		$scope.find(".paging").find(".pagingBtn").on("click", function() {
			var movePageNo = $(this).attr("data-page-no");
			
			callbackFn(movePageNo);
		});
	}
}
