

$(function(){
	_thisPage.onload();
	
	$('#btn_all').click(function(){
		$('.btn_sub').prop('checked', $(this).is(':checked'))
	});
	
	$('.btn_sub').click(function(){
		if($('.btn_sub:checked').length == 5){
			$('#btn_all').prop('checked', true);
		}else{
			$('#btn_all').prop('checked', false);
		}
	});
	
	$('.row2').click(function(){
		if($('#btn_all').is(':checked')){
			var $form = $('<form />');
    		$form.attr('action', 'dsgt_0001_01.act');
    		$form.attr('method', 'post');
    		$form.append('<input type="hidden" value="' + _dsgt_0000_00_param.svc_id + '" name="svc_id">');
    		
    		$('body').append($form);
    		$form.submit();
	        
		}else{
			alert('모두 동의하셔야 신청 가능합니다.');
		}

	});
	
	$('.white').click(function(){
		//window.open('https://www.긴급재난지원금.kr');
		window.open('http://www.gov.kr/portal/coronaPolicy/list/emergCalamSportAmt');
	});
	
	$('.typeA').click(function(){
		$('.pop_wrap').remove();
	});
	
	$('.typeB').click(function(){
		location.href = '/main_0002_01.act ';
	});
});

var _thisPage = {
		onload : function(){
			//alert('미신청 시 지원금 전액이 자동 기부되므로 전액 기부를 하시려면 별도 신청을 하지 않으셔도 됩니다.\n- 기부금은 고용보험기금 재원으로 고용안정, 실업급여 등을 위해 쓰이며 2020년 연말정산 시 15% 세액 공제 혜택이 제공됩니다');
		}

};