/**
 * <pre>
 *  PROJECT
 * @COPYRIGHT (c) 2009-2015 WebCash, Inc. All Right Reserved.
 *
 * @File Name      : dsgt_0006_02.js
 * @File path      : ZEROPAY_SPC_STATIC/web/js/jex/zeropay_spc/dsgt
 * @author         : 제해준 ( jhjun07@gmail.com )
 * @Description    : 긴급재난지원금 신청확인 본인인증 팝업
 * @History        : 20200508232315, 제해준
 * </pre>
 **/

var timer = null;
var minute = 3;
var second = 0;

$(function(){
	_thisPage.onload();
	
	$('input[type=radio]').click(function(){
		$('input[type=radio]').removeClass('on');
		$(this).addClass('on');
	});
	
	$('.all_chk').click(function(e){
		var _target = $(e.target);
		
		if(!_target.is('.all_chk input[type=checkbox]')){
			$('dd').toggle();
		}
	});

	$('.all_chk input[type=checkbox]').click(function(){
		$('dd input[type=checkbox]').prop('checked', $(this).is(':checked'));
		
		if($(this).is(':checked')){
	//		$('.btn_botm > .inner > a').addClass('on');
		}else{
	//		$('.btn_botm > .inner > a').removeClass('on');
		}
	});
	
	$('dd input[type=checkbox]').click(function(){
		if($('dd input[type=checkbox]:checked').length == 4){
			$('.all_chk input[type=checkbox]').prop('checked', true);
	//		$('.btn_botm > .inner > a').addClass('on');
		}else{
			$('.all_chk input[type=checkbox]').prop('checked', false);
	//		$('.btn_botm > .inner > a').removeClass('on');
		}
	});
	//내외국인
	$('.slt_type:eq(0)').click(function(){
		$(this).find('.ly_slt_type').show();
	});
	
	$('.slt_type:eq(0) .ly_slt_type li').click(function(){
		$(this).closest('div').prev().find('.tit').text($(this).text()).css('color', 'black');
		$('#ntv').val($(this).data('ntv'));
	});
	
	
	// 성별
	$('.slt_type:eq(1)').click(function(){
		$(this).find('.ly_slt_type').show();
	});
	
	$('.slt_type:eq(1) .ly_slt_type li').click(function(){
		$(this).closest('div').prev().find('.tit').text($(this).text()).css('color', 'black');
		$('#gndr').val($(this).data('gndr'));
	});
	
	 // html 클릭시 모든 레이어 닫기
    $( document ).on("click", "html", function(e){
        var _target = $(e.target);

        if(!_target.is('.slt_type:eq(0) > div > a')){
            $('.ly_slt_type:eq(0)').hide();
        }
        if(!_target.is('.slt_type:eq(1) > div > a')){
            $('.ly_slt_type:eq(1)').hide();
        }
    });
	
	
	$('#sms_cert_no').keyup(function(){
		if($(this).val().length == 6){
			$('.btn_botm > .inner > a').addClass('on');
		}else{
			$('.btn_botm > .inner > a').removeClass('on');
		}
	});
	// 통신사 이용약관 동의
	$('dd li:eq(0)').click(function(e){
		var _target = $(e.target);
		if(!_target.is('dd li:eq(0) input[type=checkbox]')){
			var gd = '01';
			$('input[type=radio]').each(function(){ 
				if($(this).hasClass('on')){
					gd = $(this).val();
				} 
			});
			window.open('/dsgt_0003_02.act?gb=' + gd, 'pop2', 'width=465, height=588, left=500, top=50, menubar=1, resizable=0, scrollbars=yes, resizable=no, toolbars=no, menubar=no');
		}
	});
	$('dd li:eq(1)').click(function(e){
		var _target = $(e.target);
		if(!_target.is('dd li:eq(1) input[type=checkbox]')){
			window.open('/dsgt_0003_03.act', 'pop3', 'width=465, height=588, left=500, top=50, menubar=1, resizable=0, scrollbars=yes, resizable=no, toolbars=no, menubar=no');

		}
	});
	$('dd li:eq(2)').click(function(e){
		var _target = $(e.target);
		if(!_target.is('dd li:eq(2) input[type=checkbox]')){
			window.open('/dsgt_0003_04.act', 'pop4', 'width=465, height=588, left=500, top=50, menubar=1, resizable=0, scrollbars=yes, resizable=no, toolbars=no, menubar=no');
		}
	});
	$('dd li:eq(3)').click(function(e){
		var _target = $(e.target);
		if(!_target.is('dd li:eq(3) input[type=checkbox]')){
			window.open('/dsgt_0003_05.act', 'pop5', 'width=465, height=588, left=500, top=50, menubar=1, resizable=0, scrollbars=yes, resizable=no, toolbars=no, menubar=no');
		}
	});
	
	// 인증번호 숫자만
	$('#sms_cert_no, #birth, #clph_no').on('keyup', function(){
		$(this).val($(this).val().replace(/[^0-9]/g,''));
	});
	
	$('.btn_botm > .inner').click(function(){
		var birthCheck = RegExp(/^(19[0-9][0-9]|20\d{2})(0[0-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])$/);

		if(!$(this).find('a').hasClass('on')){
			return;
		}
		// 성명 확인
		if( $('#name').val().length == 0 ){
			alert('성명을 입력해주세요');
			return;
		}
		
		// 생년월일 확인
		if( $('#birth').val().length == 0 ){
			alert('생년월일을 입력해주세요.');
			return;
		}
		if($('#birth').val().length != 8){
			alert('생년월일은 숫자 8자입니다. (예:19801231)');
			return;
		}
		if(!birthCheck.test($('#birth').val())){
    		alert('생년월일이 유효하지 않습니다.');
    		return false;
    	}
		if($('#gndr').val() == ''){
			alert('성별을 선택해주세요.');
			return;
		}
		// 이용약관 확인
		if($('.all_chk input[type=checkbox]').is(':checked') == false ){
			alert('이용약관을 동의해주세요.');
			return;
		}
		// 전화 번호
		if( $('#clph_no').val().length  == 0 ){
			alert('전화번호를 입력하세요');
			return;
		}
		
		
		
		if(minute == 0 && second == '00' ){
			alert('인증시간이 만료되었습니다.');
			return;
		}
		
		var sms_cert_no = $('#sms_cert_no').val();
		
		if(sms_cert_no.length == 0){
			alert('인증번호를 입력하세요.');
			return;
		}
		if(sms_cert_no.length > 0 && sms_cert_no.length > 6){
			alert('인증번호는 숫자 6자입니다.');
			return;
		}
		
/*		var data = {
				TRSC_UNQ_NO:$('#trsc_unq_no').val(),
				CLPH_NO:$('#clph_no').val(),
				SMS_CERT_NO:sms_cert_no,
				BRDT : $('#birth').val()
		};
		*/
		var data = {
				TX_SEQ_NO 	: $('#trsc_unq_no').val(),
				TEL_NO 		: $('#clph_no').val(),
				OTP_NO 		: sms_cert_no,
				BIRTHDAY 	: $('#birth').val(),
		};
		
		fn_certifyNumberConfirm(data);

	});
	
	$('.btn_01').click(function(){
		//var birthCheck = RegExp(/([0-9]{2}(0[1-9]|1[0-2])(0[1-9]|[1,2][0-9]|3[0,1]))/);
		var birthCheck = RegExp(/^(19[0-9][0-9]|20\d{2})(0[0-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])$/);
		
		var data = {
				NAME:'',
				BRDT:'',
				GNDR:'',
				IN_FRNR_DV_CD:'',
				TEL_CMM_CD:'',
				ECNMC_TEL_CMM_YN:'',
				CLPH_NO:'',
				BSNN_NO:'',
				USER_ID:''
			}
		
		var telCmmCd = '01';
		$('input[type=radio]').each(function(){ 
			if($(this).hasClass('on')){
				telCmmCd = $(this).val();
			} 
		});
		
		var name = $('#name').val(); // 이름
		var brdt = $('#birth').val(); // 생년월일
		var ecnmcTelCmmYn = '';  // 알뜰폰유무
		var clph_no = $('#clph_no').val() // 전화 번호
		
		if($('#ecnmc').is(':checked')){
			ecnmcTelCmmYn = 'Y';
		}else{
			ecnmcTelCmmYn = 'N';
		}
		
		// 이용약관 확인
		if($('.all_chk input[type=checkbox]').is(':checked') == false ){
			alert('이용약관을 동의해주세요.');
			return;
		}
		
		// 성명 확인
		if( name.length == 0 ){
			alert('성명을 입력해주세요');
			return;
		}
		
		// 생년월일 확인
		if(brdt.length == 0){
			alert('생년월일을 입력해주세요.');
			return;
		}
		if(brdt.length != 8){
			alert('생년월일은 숫자 8자입니다. (예:19801231)');
			return;
		}
		
		if(!birthCheck.test(brdt)){
    		alert('생년월일이 유효하지 않습니다.');
    		return false;
    	}
		
		if($('#gndr').val() == ''){
			alert('성별을 선택해주세요.');
			return;
		}
	
		// 전화 번호
		if( clph_no.length  == 0 ){
			alert('전화번호를 입력하세요');
			return;
		}
		
		/*data.NAME = name;
		data.BRDT = brdt;
		//data.GNDR = gndr;
		data.GNDR = $('#gndr').val();
		//data.IN_FRNR_DV_CD = '1';
		data.IN_FRNR_DV_CD = $('#ntv').val();
		data.TEL_CMM_CD = telCmmCd;
		data.ECNMC_TEL_CMM_YN = ecnmcTelCmmYn;
		data.CLPH_NO = clph_no;*/
		
		data.NAME = name;
		data.BIRTHDAY = brdt;
		data.TEL_COM_CD = telCmmCd;
		data.TEL_NO = clph_no;
		data.ECNMC_TEL_CMM_YN = ecnmcTelCmmYn;
		data.SEX_CD = $('#gndr').val();
		data.NTV_FRNR_CD = $('#ntv').val();
		
		_thisPage.fn_certifyNumberCall(data);
	
	});
	
});

var _thisPage = {
		onload : function(){
			
		}

	, fn_certifyNumberCall : function(data){
			
			var jexAjax = jexjs.createAjaxUtil("comm_0001_01_r004");
			jexAjax.set(data);
			jexAjax.execute( function( dat ) {
				if(dat.RSLT_CD == 'B000'){
					// $('#trsc_unq_no').val(dat.TRSC_UNQ_NO);
					$('#trsc_unq_no').val(dat.TX_SEQ_NO);
					 fn_timmerStart();
					alert('인증번호를 발송하였습니다.');
				}else{
					alert('인증번호 호출을 실패 하였습니다.\n' + dat.RSLT_MSG + '(' + dat.RSLT_CD + ')');
				}
				
				/*
				console.log(dat)
			    if( jexjs.isJexError( dat ) ) {
			        var errCode = jexjs.getJexErrorCode( dat );
			        var errMsg = jexjs.getJexErrorMessage( dat );

			        //alert( errCode + " : " + errMsg );
			        alert('인증번호 호출을 실패 하였습니다.', errMsg +'('+errCode+')', '');
			        return;
			    }
			    $('#trsc_unq_no').val(dat.TRSC_UNQ_NO);
			    fn_timmerStart();
			    
			    alert('인증번호를 발송하였습니다.', '', '');
			    
			*/
				});
		}

};

function fn_timmerStart(){
	
	clearInterval(timer);
	minute = 3;
	second = 0;
	timer = setInterval(function () {
		// 설정
		if(second == 0 && minute == 0 ){
			clearInterval(timer); /* 타이머 종료 */
		}else{
			second--;				
			// 분처리
			if(second < 0){
				minute--;
				second = 59;
			}
			if(second < 10 ){
			    second = "0"+second;
			}
		}
		$('.time').html("0"+minute+":"+second);
		
	}, 1000); /* millisecond 단위의 인터벌 */
    
}

/**
 * 인증번호 확인
 * @param data
 * @returns
 */
function fn_certifyNumberConfirm(data){

	var jexAjax = jexjs.createAjaxUtil("comm_0001_01_r005");
	jexAjax.set(data);
	jexAjax.execute( function( dat ) {
	/*    if( jexjs.isJexError( dat ) ) {
	        var errCode = jexjs.getJexErrorCode( dat );
	        var errMsg = jexjs.getJexErrorMessage( dat );

	        //alert( errCode + " : " + errMsg );
	        alert('본인인증이 실패하였습니다.', errMsg +'('+errCode+')', '');
	        return;
	    }*/
	    if( dat.RSLT_CD == 'B000'){
	    	alert('본인인증이 성공하였습니다.');
	    	
	    	window.opener.name = 'parentPage2'; // 부모창의 이름 설정
	    	
	    	var $form = $('<form />');
			$form.attr('action', 'dsgt_0006_01.act');
			$form.attr('method', 'post');
			$form.attr('target', 'parentPage2');
			$form.append('<input type="hidden" value="' + $('#clph_no').val() + '" name="clph_no">');
			$form.append('<input type="hidden" value="' + dat.CI + '" name="ci">');

			//$(opener.document).find('body').append($form);
			$('body').append($form);
			$form.submit();
			
			window.close();
	    }else{
	    	alert('본인인증이 실패하였습니다.\n' + dat.RSLT_MSG + '(' + dat.RSLT_CD + ')');
	    }
	});
}

