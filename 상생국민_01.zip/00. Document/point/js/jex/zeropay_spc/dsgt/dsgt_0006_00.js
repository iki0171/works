
$(function(){
	_thisPage.onload();
	
	$('.inner > a').click(function(){
		var popup = window.open("/dsgt_0006_02.act" , "pop2", "width=456, height=588, left=100, top=50, menubar=1, resizable=0, scrollbars=yes, resizable=no, toolbars=no, menubar=no");
	});
});

var _thisPage = {
		
		onload : function(){
			
		}
};