
var totAmt = 0;

$(function(){
	_thisPage.onload();
	//확인
	$("#enter").on("click",function(){
		sessionRemove();
		location.href = '/main_0002_01.act';
	});
	//가족과 함께 쓰기
	$("#dsgt").on("click",function(){
		var jexAjax = jexjs.createAjaxUtil("dsgt_0006_01_r002");
		jexAjax.execute( function( dat ) {
			if(dat.RSLT_CD == "0000"){
				location.href="/dsgt_0007_01.act";
			}else{
				sessionRemove();
				alert(dat.RSLT_MSG);
				location.href = '/main_0002_01.act';
			}
		});
		
		
	});
	
	//기부금액변경
	$("#modify").click(function(){
		$("#INPUT_DONA_AMT").closest("tr").show();
		$("#DONA_AMT").closest("tr").hide();
		$("#INPUT_DONA_AMT").val($("#DONA_AMT").text().replace("만원", ""));
		$("#dsgt, #enter, #modify").hide();
		$("#save, #cancel").show();
	});
	//취소
	$("#cancel").click(function(){
		$("#INPUT_DONA_AMT").closest("tr").hide();
		$("#DONA_AMT").closest("tr").show();
		$("#dsgt, #enter, #modify").show();
		$("#save, #cancel").hide();
		$("#APPC_AMT").text(appcAmt + "만원");
		
	});
	
	$('#INPUT_DONA_AMT').on('keyup', function(){
		$(this).val($(this).val().replace(/[^0-9]/g,''));
		
		if($(this).val() > totAmt){
			$(this).val(totAmt)
		}
		
		$('#APPC_AMT').text(totAmt - Number(fintech.common.null2zero($(this).val())) + "만원");
	});
	
	$("#save").click(function(){
		$(".pop_wrap").show();
	});
	
	
	$(".typeA").click(function(){
		$(".pop_wrap").hide();
		var uAppcAmt = Number(fintech.common.null2zero($("#APPC_AMT").text().replace("만원", "")))  * 10000 ;
		var uDonaAmt = Number(fintech.common.null2zero($("#INPUT_DONA_AMT").val())) * 10000;
		
		var jexAjax = jexjs.createAjaxUtil("dsgt_0006_01_u001");
		jexAjax.set("APPC_AMT", uAppcAmt);
		jexAjax.set("DONA_AMT", uDonaAmt);
		jexAjax.set("NAME", _name);
		jexAjax.execute( function( dat ) {
			if(dat.RSLT_CD == "0000"){
				$("#INPUT_DONA_AMT").closest("tr").hide();
				$("#DONA_AMT").closest("tr").show();
				$("#dsgt, #enter, #modify").show();
				$("#save, #cancel").hide();
				_thisPage.onload();
				alert("정상처리되었습니다.");
			}else if(dat.RSLT_CD == "9998"){
				alert("신청 당일에만 변경할 수 있습니다.");
			}else if(dat.RSLT_CD == "9997"){
				alert("지급받을금액 기부금액 합계가 지원금액과 일치하지않습니다. 신청결과 확인 페이지에서 확인 후 처리해 주시기 바랍니다.");
			}else{
				alert("처리중 에러가 발생하였습니다.");
			}
		});
	
	
	});
	$(".typeB").click(function(){
		$(".pop_wrap").hide();
	});
	
});
var _thisPage = {
		onload : function (){
			_thisPage.searchData();
			_thisPage.datecheck();
		},
		searchData : function (){
			var jexAjax = jexjs.createAjaxUtil("dsgt_0006_01_r001");
//			jexAjax.set("CLPH_NO",$("#CLPH").val());
			jexAjax.execute( function( dat ) {
				if(dat.COMMON_HEAD.CODE=="Session Disconnect"){
					alert("올바르지 않은 접근입니다.");
					location.href="dsgt_0006_00.act";
					return;
				}
				fn_setData(dat);
			});
		},
		datecheck : function(){
			var jexAjax = jexjs.createAjaxUtil("dsgt_0006_01_r002");
			jexAjax.execute( function( dat ) {
				if(dat.RSLT_CD != "0000"){
					$("#dsgt").remove();
					$("#modify").remove();
				}
			});
			
			
		
		}
}
function fn_setData(data){
	
	if(fintech.common.null2void(data.NAME) == ""){
		$(".nDis_tblView").hide();
		$("h3").text("고객님께서는 제로페이 모바일상품권을 통해 정부 긴급재난지원금을 신청하신 내역이 없습니다.");
		return;
	}
	
	// 기부금 신청여부
/*	if(data.DONA_CNT != "0"){
		alert("고객님께서는 기부금 신청 확인을 안했습니다.");
		location.href = "/dsgt_0000_00.act";
		return
	}
	*/
	_name = data.NAME;
	$("#APPC_AMT").html(data.APPC_AMT=="0"?"0만원":parseInt(data.APPC_AMT)/10000+"만원");
	$("#DONA_AMT").html(data.DONA_AMT=="0"?"0만원":parseInt(data.DONA_AMT)/10000+"만원");
	$("#CLPH_NO").html(formatter.phone(data.CLPH_NO));
	$("#REG_DTM").html(formatter.datetime(data.REG_DTM, 'yyyy-mm-dd hh24:mi:ss'));
	$("#ZPCD_NM").html(data.ZPCD_NM);
	$("#NAME").html( data.NAME + " (세대원 : " + data.HSHD_CNT + "명 )" );
	$("#TOP_NAME").html(data.NAME);
	var chk = fn_chk(data.REG_DTM);
	totAmt = Number(fintech.common.null2zero(data.SPPT_AMT)) / 10000;
	appcAmt = Number(fintech.common.null2zero(data.APPC_AMT)) / 10000;
	if(chk){
		$("#dsgt").show();	
	} else {
		$("#dsgt").remove();
	}
}
function fn_chk(dtm){
	dtm = dtm.substring(0,12);
	var now  =new Date();
	var year =now.getFullYear();
	var month=now.getMonth();
	var date =now.getDate();
	var m    = (month+1>9) ? month+1 : '0'+(month+1);
	var d    = (date>9) ? date : '0'+date;
	
	var dateTime = year+m+d+"2350";
	var chk = parseInt(dateTime)-parseInt(dtm);
	
	if(chk>=0){
		return true;
	} else {
		return false;
	}
}

function sessionRemove(){
	var request = new XMLHttpRequest();
	request.open("POST", "view/jex/zeropay_spc/comm/sessionRemove.jsp", false);
	request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	request.setRequestHeader("Cache-Control", "no-cache");
	request.send();
}