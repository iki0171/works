function maskarea(){
	var mwidth = $(document).width();
	var mheight = $(document).height();
	$(".mask").css({"width":mwidth,"height":mheight});
	$("body").css({"overflow":"hidden","height":"100%"});
}

$(function() {

	// ����ũ�� Ȯ��ȳ�


	/* ���ε��� ���� */
	$(".fixed_table").attr("tabindex","0");


	/* ��ü�޴����� */


	/* �����̼� �޴� */


	/* �Ǹ޴� */

	// �˻����ǿ���
	$(".btn_view").click(function() {
		var btn = $(this);
		var temp = $(btn).parent().next(".cont_body");
		if ($(temp).css("display") == "none") {
			$(temp).show();
			$(btn).children("i").removeClass("bg_up").addClass("bg_down");
			$(btn).children("em").text("����α�");
			$(btn).css({"background":"#eaeaea", "color":"#555"});
			$(btn).prev("p").css("display","none");
		} else {
			$(temp).hide();
			$(btn).children("i").removeClass("bg_down").addClass("bg_up");
			$(btn).children("em").text("�󼼰˻�");
			$(btn).css({"background":"#4e7fce", "color":"#fff"});
			$(btn).prev("p").css("display","block");
		}
	});

	// ������ �׷� ����
	$("#cnt_group .title").click(function() {
		var row = $(this);
		var content = $(row).next(".cont_body");
		if ($(content).css("display") == "block") {
			$(content).hide();
			$(row).addClass("cnt_up");
			$(row).children(".btn_up em").text("����");
			$(row).parent().css({"border-radius":"12px", "box-shadow":"none"});
		} else {
			$(content).show();
			$(row).removeClass("cnt_up");
			$(row).children(".btn_up em").text("�ݱ�");
			$(row).parent().css({"border-radius":"20px", "box-shadow":"0 1px 8px #ddd"});
		}
	});

	/* ������ üũ�ڽ� üũ�Ҷ� �� */
	$(".i_radio").each(function(i){
		var $this = $(this);
		$this.children(":radio").on("focusin focusout", function() {
			$this.toggleClass("radio_focus");
		});
	});

	$(".radio_btn").each(function(i){
		var $this = $(this);
		$this.children(":radio").on("focusin focusout", function() {
			$this.toggleClass("radio_focus");
		});
	});

	$(".i_check").each(function(i){
		var $this = $(this);
		$this.children(":checkbox").on("focusin focusout", function() {
			$this.toggleClass("checkbox_focus");
		});
	});

});
