(function (global, $) {
    'use strict'

    $('a').click(function () {
        if ($(this).attr('href') == '#none') {
            return false
        };
    });

    $('.html').each(function () {
        var $this = $(this);
        var code = $this.html();
        var $btn = $('<a class="g-btn">view html</a>');
        $this.after('<code class="code-view xml"></code>');
        var $view = $this.next($('.code-view'));
        $view.text(code).wrap('<pre />');
        $this.after($btn);
    });

    $('code.javascript').each(function () {
        $('<a class="g-btn">script</a>').insertBefore($(this).parent());
    });

    $('.g-btn').click(function () {
        $(this).toggleClass('open');
        $(this).next('pre').toggle();
    })

    $('code.xml, code.javascript').each(function () {
        var html = $(this).html(),
            lineMatch = html.match(/\n/g);

        if (lineMatch) {
            var spaceMath = html.match(/^(\s|\t)+/);
            if (spaceMath) {
                html = html.replace(new RegExp(spaceMath[0], 'mg'), '\n');
            }
        } else {
            html = html.replace(/^\s+/, '');
        };

        $(this).html(html);
        if ($(this).hasClass('xml')) {
            var $copyBtn = $('<a href="#none" class="btn-copy">COPY</a>');
            $(this).parent().append($copyBtn);
            $copyBtn.on('click', function (e) {
                var $input = $('<textarea style="position:absolute">' + html + '</textarea>');
                $('body').append($input);
                $input.select();
                document.execCommand('Copy');
                $input.remove();
                $copyBtn.addClass('complete').text('copy complete!');
                setTimeout(function () {
                    $copyBtn.removeClass('complete').text('copy');
                }, 1000);
            });
        }
    })

	$('pre code').each(function (i, block) {
		hljs.highlightBlock(block);
	});

	$(".left-menu li a").click(function() {
        var idx = $(".left-menu li a").index(this);
		$(".left-menu li").removeClass("on");
        $(".left-menu li").eq(idx).addClass("on");
	});

  // to top
  var scrollDiv = document.createElement('div')
  $(scrollDiv).attr('id', 'toTop').html('<a href="#none">to Top</a>').appendTo('.guide-main')
  $(window).scroll(function () {
    if ($(this).scrollTop() != 0) {
      $('#toTop').fadeIn()
      $('.left-menu').addClass('move')
    } else {
      $('#toTop').fadeOut()
      $('.left-menu').removeClass('move')
    }
  })
  $('#toTop').click(function () {
    $('body,html').animate({scrollTop: 0},	600)
    return false
  })
}(window, window.jQuery))
